package com.example.zelismapapp;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.zelismapapp.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions()
                .position(sydney)
                .title("Marker in Sydney")
                .snippet("Hanna's Dream")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        LatLng HPU = new LatLng(35.97037478066102, -79.99344070399272);
        mMap.addMarker(new MarkerOptions()
                .position(HPU)
                .title("Entrance to Couch")
                .snippet("Hanna's 24/7")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(HPU));

        LatLng secondHome = new LatLng(41.279772052011424, -81.84625757570873);
        mMap.addMarker(new MarkerOptions()
                .position(secondHome)
                .title("Second Home")
                .snippet("2006-2020")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(secondHome));

        LatLng firstHome = new LatLng(41.28018173647859, -81.8455427424163);
        mMap.addMarker(new MarkerOptions()
                .position(firstHome)
                .title("First Home")
                .snippet("2002-2006")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(firstHome));

        LatLng currentHome = new LatLng(26.290418813933577, -81.7197437200301);
        mMap.addMarker(new MarkerOptions()
                .position(currentHome)
                .title("Current Home")
                .snippet("2020-now")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(currentHome));

        LatLng gradeSchool = new LatLng(41.38474464394946, -81.77970677566115);
        mMap.addMarker(new MarkerOptions()
                .position(gradeSchool)
                .title("K-8 School")
                .snippet("2008-2016")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(gradeSchool));

        LatLng highSchool = new LatLng(41.469118968916355, -81.8504157756229);
        mMap.addMarker(new MarkerOptions()
                .position(highSchool)
                .title("High School")
                .snippet("2016-2020")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(highSchool));

        LatLng college = new LatLng(35.9773712872697, -79.99762553194631);
        mMap.addMarker(new MarkerOptions()
                .position(college)
                .title("University")
                .snippet("2020-2024")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(college));

        LatLng volunteer2019 = new LatLng(-17.105003955210027, 177.22651729298852);
        mMap.addMarker(new MarkerOptions()
                .position(volunteer2019)
                .title("Volunteer Abroad")
                .snippet("Summer 2019")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA)));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(volunteer2019));
    }

}